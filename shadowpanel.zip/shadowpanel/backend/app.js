require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');

const { seedAdmin } = require('./models/db');
const authRoutes = require('./routes/auth');
const serverRoutes = require('./routes/servers');

const app = express();
const PORT = process.env.PORT || 3000;

seedAdmin(process.env.ADMIN_EMAIL || 'admin@example.com', process.env.ADMIN_PASSWORD || 'admin');

app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'insecure_dev_secret_change_me',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 12 },
  })
);

app.use('/api/auth', authRoutes);
app.use('/api/servers', serverRoutes);

const frontendDir = path.join(__dirname, '..', 'frontend', 'public');
app.use(express.static(frontendDir));

app.get('*', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`[shadowpanel] panel listening on port ${PORT}`);
});
