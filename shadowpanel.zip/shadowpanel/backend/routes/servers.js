const express = require('express');
const ctrl = require('../controllers/serverController');

const router = express.Router();
router.use(ctrl.requireAuth);

router.get('/catalog', ctrl.catalog);
router.get('/', ctrl.list);
router.post('/', ctrl.create);
router.post('/:id/power/:action', ctrl.loadOwnedServer, ctrl.power);
router.get('/:id/logs', ctrl.loadOwnedServer, ctrl.logs);

module.exports = router;
