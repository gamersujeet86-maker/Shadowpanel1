const Docker = require('dockerode');

const socketPath = process.env.DOCKER_SOCKET || '/var/run/docker.sock';
const docker = new Docker({ socketPath });

// Curated set of images an owner can pick from when creating a server.
// Keep this list to images that run standalone with no extra setup.
const CATALOG = [
  { key: 'minecraft-java', label: 'Minecraft (Java, Paper)', image: 'itzg/minecraft-server', port: 25565, env: ['EULA=TRUE', 'TYPE=PAPER'] },
  { key: 'minecraft-bedrock', label: 'Minecraft (Bedrock)', image: 'itzg/minecraft-bedrock-server', port: 19132, env: ['EULA=TRUE'] },
  { key: 'terraria', label: 'Terraria', image: 'ryshe/terraria', port: 7777, env: [] },
  { key: 'valheim', label: 'Valheim', image: 'lloesche/valheim-server', port: 2456, env: [] },
  { key: 'node-app', label: 'Generic Node.js app (Ubuntu base)', image: 'node:20-bullseye', port: 3000, env: [] },
  { key: 'ubuntu', label: 'Plain Ubuntu (shell only)', image: 'ubuntu:24.04', port: null, env: [] },
];

function findCatalogEntry(key) {
  return CATALOG.find((c) => c.key === key);
}

async function ensureImage(image) {
  const images = await docker.listImages({ filters: { reference: [image] } });
  if (images.length) return;
  await new Promise((resolve, reject) => {
    docker.pull(image, (err, stream) => {
      if (err) return reject(err);
      docker.modem.followProgress(stream, (err2) => (err2 ? reject(err2) : resolve()));
    });
  });
}

async function createServer({ name, catalogKey, memoryMb, cpuCores, hostPort }) {
  const entry = findCatalogEntry(catalogKey);
  if (!entry) throw new Error('Unknown server type');

  await ensureImage(entry.image);

  const exposedPorts = {};
  const portBindings = {};
  if (entry.port) {
    const key = `${entry.port}/tcp`;
    exposedPorts[key] = {};
    portBindings[key] = [{ HostPort: String(hostPort) }];
  }

  const container = await docker.createContainer({
    name: `shadowpanel_${name}_${Date.now()}`,
    Image: entry.image,
    Env: entry.env,
    Tty: true,
    OpenStdin: true,
    ExposedPorts: exposedPorts,
    HostConfig: {
      PortBindings: portBindings,
      Memory: memoryMb * 1024 * 1024,
      NanoCpus: Math.round(cpuCores * 1e9),
      RestartPolicy: { Name: 'unless-stopped' },
    },
  });

  await container.start();
  return { containerId: container.id, image: entry.image, port: entry.port };
}

async function action(containerId, act) {
  const container = docker.getContainer(containerId);
  if (act === 'start') return container.start();
  if (act === 'stop') return container.stop();
  if (act === 'restart') return container.restart();
  if (act === 'kill') return container.kill();
  if (act === 'remove') return container.remove({ force: true });
  throw new Error('Unknown action');
}

async function status(containerId) {
  try {
    const container = docker.getContainer(containerId);
    const info = await container.inspect();
    return {
      running: info.State.Running,
      status: info.State.Status,
      startedAt: info.State.StartedAt,
    };
  } catch (e) {
    return { running: false, status: 'missing' };
  }
}

async function logs(containerId, tail = 200) {
  const container = docker.getContainer(containerId);
  const buf = await container.logs({ stdout: true, stderr: true, tail, timestamps: false });
  // Docker multiplexes stdout/stderr with an 8-byte header per frame; strip it.
  let out = '';
  let i = 0;
  while (i < buf.length) {
    const len = buf.readUInt32BE(i + 4);
    out += buf.slice(i + 8, i + 8 + len).toString('utf8');
    i += 8 + len;
  }
  return out;
}

module.exports = { docker, CATALOG, findCatalogEntry, createServer, action, status, logs };
