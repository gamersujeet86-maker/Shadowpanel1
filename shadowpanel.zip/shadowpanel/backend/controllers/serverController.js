const { db } = require('../models/db');
const dockerApi = require('../api/docker');

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  next();
}

function catalog(req, res) {
  res.json(dockerApi.CATALOG.map(({ key, label }) => ({ key, label })));
}

async function list(req, res) {
  const rows = db.prepare('SELECT * FROM servers WHERE owner_id = ? ORDER BY created_at DESC').all(req.session.userId);
  const withStatus = await Promise.all(
    rows.map(async (r) => ({ ...r, ...(await dockerApi.status(r.container_id)) }))
  );
  res.json(withStatus);
}

async function create(req, res) {
  const { name, catalogKey, memoryMb, cpuCores, hostPort } = req.body;
  if (!name || !catalogKey || !hostPort) {
    return res.status(400).json({ error: 'name, catalogKey and hostPort are required' });
  }
  try {
    const result = await dockerApi.createServer({
      name,
      catalogKey,
      memoryMb: Number(memoryMb) || 1024,
      cpuCores: Number(cpuCores) || 1,
      hostPort: Number(hostPort),
    });
    const info = db
      .prepare(
        'INSERT INTO servers (owner_id, name, image, container_id, port_map, memory_mb, cpu_cores) VALUES (?, ?, ?, ?, ?, ?, ?)'
      )
      .run(req.session.userId, name, result.image, result.containerId, String(hostPort), Number(memoryMb) || 1024, Number(cpuCores) || 1);
    res.json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

function loadOwnedServer(req, res, next) {
  const row = db.prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?').get(req.params.id, req.session.userId);
  if (!row) return res.status(404).json({ error: 'Server not found' });
  req.serverRow = row;
  next();
}

async function power(req, res) {
  try {
    await dockerApi.action(req.serverRow.container_id, req.params.action);
    if (req.params.action === 'remove') {
      db.prepare('DELETE FROM servers WHERE id = ?').run(req.serverRow.id);
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

async function logs(req, res) {
  try {
    const text = await dockerApi.logs(req.serverRow.container_id, 300);
    res.json({ logs: text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

module.exports = { requireAuth, catalog, list, create, loadOwnedServer, power, logs };
