# ShadowPanel

A lightweight, self-hosted server control panel in the spirit of Pterodactyl.
It manages Docker containers (game servers, small apps) through a web UI:
create, start, stop, restart, delete, and tail logs — no SSH required after
setup.

**Stack:** Node.js + Express, SQLite (via `better-sqlite3`), Docker Engine
API (via `dockerode`). No build step, single process.

> This is a lightweight panel, not a 1:1 Pterodactyl clone — there's no
> separate multi-node daemon ("Wings"), no SFTP, no file manager yet. It's
> built for one VPS running a handful of containers under one admin panel.
> See "Roadmap" below for what's next.

```
ShadowPanel/
├── backend/
│   ├── api/            # Docker Engine API wrapper (dockerode)
│   ├── controllers/     # request handlers
│   ├── models/          # SQLite (users, servers)
│   ├── routes/          # Express routers
│   └── app.js            # entrypoint
├── frontend/
│   ├── public/           # served UI (HTML/CSS/JS, no build step)
│   └── src/              # reserved for a future framework build step
├── installer/
│   └── install.sh
├── docker-compose.yml
├── Dockerfile
├── package.json
├── README.md
└── LICENSE
```

---

## 1. Publish this to GitHub

From this folder:

```bash
git init
git add .
git commit -m "Initial commit: ShadowPanel"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/ShadowPanel.git
git push -u origin main
```

Then open `installer/install.sh` and replace `YOUR_GITHUB_USERNAME` in the
`REPO_URL` default with your actual GitHub username (or your fork's URL),
and commit that change too — it's what lets the one-line installer below
pull your copy of the code onto a fresh VPS.

`.env` and `data/` (the SQLite database) are already excluded via
`.gitignore` so you won't accidentally commit secrets or server data.

---

## 2. Install on any VPS — one command

On a fresh Ubuntu/Debian VPS, run:

```bash
bash <(curl -s https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/ShadowPanel/main/installer/install.sh)
```

(Run it as root, or prefix with `sudo -E` if you're not root.)

The script will:
1. Install Docker Engine and Node.js 20 if they're not already present
2. Clone this repo into `/opt/shadowpanel`
3. Prompt you for a panel port, admin email, and admin password (or
   auto-generate a password if you leave it blank)
4. Register and start a `shadowpanel` systemd service that auto-restarts
5. Open the chosen port through `ufw` if it's active
6. Print the panel URL when it's done

Re-running it later just pulls the latest code and restarts the service —
it won't overwrite an existing `.env`.

**Note on container-based sandboxes (CodeSandbox, etc.):** ShadowPanel
manages Docker containers, so it needs a host where the Docker daemon
itself can run. A plain container sandbox without Docker access can still
run the panel's web server, but server creation/power actions will fail
until a real Docker socket is available — a small VPS (DigitalOcean,
Hetzner, a home server, etc.) is the intended target.

### Option B: Docker Compose

If your VPS already has Docker installed:

```bash
git clone https://github.com/YOUR_GITHUB_USERNAME/ShadowPanel.git
cd ShadowPanel
cp .env.example .env   # edit values first
docker compose up -d --build
```

This runs the panel itself in a container, mounting the host's Docker
socket so it can still manage other containers ("Docker-outside-of-Docker",
not Docker-in-Docker).

### Option C: Manual (any OS with Docker + Node 18+)

```bash
git clone https://github.com/YOUR_GITHUB_USERNAME/ShadowPanel.git
cd ShadowPanel
cp .env.example .env   # edit values inside
npm install
npm start
```

---

## 3. Using the panel

1. Visit `http://<server-ip>:<port>` and log in with the admin email/password
   set during install (or in `.env`).
2. Click **+ New server**, pick a server type (Minecraft, Terraria, Valheim,
   a plain Ubuntu shell, or a Node.js base image), set the host port,
   memory, and CPU limit, then create it.
3. Start/stop/restart/delete from each server card, and open **Console** to
   tail its logs.

### Adding more server types

Edit the `CATALOG` array in `backend/api/docker.js` — each entry is just a
Docker image, the port it listens on, and any environment variables it
needs. Any image that runs standalone (no external config files required)
works.

---

## Roadmap toward closer Pterodactyl parity

Not built yet, but the structure leaves room for these:
- File manager (browse/edit files inside a container's volume)
- Subusers / per-server permissions
- "Egg"-style JSON server-type definitions instead of the hardcoded catalog
- Resource usage graphs (CPU/RAM over time)

---

## Security notes before exposing this publicly

- Put the panel behind a reverse proxy (Caddy or nginx) with HTTPS/TLS.
- Change `SESSION_SECRET` and the admin password from their generated
  defaults if you ever set them manually.
- The panel process needs access to the Docker socket, which is
  effectively root-equivalent on the host — only give panel logins to
  people you'd trust with root.
- Consider a firewall rule limiting the panel port to your own IP if it's
  just for personal use.

## License

MIT — see `LICENSE`.
