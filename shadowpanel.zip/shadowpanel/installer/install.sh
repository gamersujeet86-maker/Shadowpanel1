#!/usr/bin/env bash
#
# ShadowPanel installer
# Installs Docker, Node.js, and the ShadowPanel service on a fresh
# Debian/Ubuntu VPS, then starts it as a systemd service.
#
# Run directly (recommended — keeps your terminal interactive for prompts):
#   bash <(curl -s https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/ShadowPanel/main/installer/install.sh)
#
set -euo pipefail

REPO_URL="${SHADOWPANEL_REPO:-https://github.com/YOUR_GITHUB_USERNAME/ShadowPanel.git}"
INSTALL_DIR="/opt/shadowpanel"
SERVICE_NAME="shadowpanel"
NODE_MAJOR="20"

c_green() { printf '\033[0;32m%s\033[0m\n' "$1"; }
c_yellow() { printf '\033[1;33m%s\033[0m\n' "$1"; }
c_red() { printf '\033[0;31m%s\033[0m\n' "$1"; }
die() { c_red "ERROR: $1"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run this as root, e.g.: sudo bash <(curl -s <install.sh URL>)"

command -v apt-get >/dev/null 2>&1 || die "This installer supports Debian/Ubuntu (apt-get) only."

c_green "==> Updating package index"
apt-get update -y

c_green "==> Installing base packages"
apt-get install -y ca-certificates curl gnupg git ufw

# ---------------------------------------------------------------------------
# Docker
# ---------------------------------------------------------------------------
if ! command -v docker >/dev/null 2>&1; then
  c_green "==> Installing Docker Engine"
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  . /etc/os-release
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  systemctl enable --now docker
else
  c_yellow "==> Docker already installed, skipping"
fi

# ---------------------------------------------------------------------------
# Node.js
# ---------------------------------------------------------------------------
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | sed 's/v//' | cut -d. -f1)" -lt "$NODE_MAJOR" ]; then
  c_green "==> Installing Node.js ${NODE_MAJOR}.x"
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
  apt-get install -y nodejs
else
  c_yellow "==> Node.js already installed, skipping"
fi

# ---------------------------------------------------------------------------
# Fetch application code
# ---------------------------------------------------------------------------
if [ -d "$INSTALL_DIR/.git" ]; then
  c_green "==> Updating existing install at $INSTALL_DIR"
  git -C "$INSTALL_DIR" pull --ff-only
else
  c_green "==> Cloning ShadowPanel to $INSTALL_DIR"
  rm -rf "$INSTALL_DIR"
  git clone "$REPO_URL" "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"

c_green "==> Installing npm dependencies"
npm ci --omit=dev 2>/dev/null || npm install --omit=dev

mkdir -p "$INSTALL_DIR/data"

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
if [ ! -f "$INSTALL_DIR/.env" ]; then
  c_green "==> Writing .env"
  RAND_SECRET="$(openssl rand -hex 32 2>/dev/null || head -c32 /dev/urandom | xxd -p | tr -d '\n')"

  read -rp "Panel port [3000]: " PANEL_PORT
  PANEL_PORT="${PANEL_PORT:-3000}"

  read -rp "Admin email [admin@example.com]: " ADMIN_EMAIL
  ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"

  read -rsp "Admin password [auto-generated]: " ADMIN_PASSWORD
  echo
  if [ -z "$ADMIN_PASSWORD" ]; then
    ADMIN_PASSWORD="$(openssl rand -base64 12 2>/dev/null || head -c12 /dev/urandom | base64)"
    c_yellow "Generated admin password: ${ADMIN_PASSWORD}"
    c_yellow "Save this now — it will not be shown again."
  fi

  cat > "$INSTALL_DIR/.env" <<EOF
PORT=${PANEL_PORT}
SESSION_SECRET=${RAND_SECRET}
ADMIN_EMAIL=${ADMIN_EMAIL}
ADMIN_PASSWORD=${ADMIN_PASSWORD}
DOCKER_SOCKET=/var/run/docker.sock
EOF
else
  c_yellow "==> .env already exists, leaving it untouched"
  PANEL_PORT="$(grep -E '^PORT=' "$INSTALL_DIR/.env" | cut -d= -f2)"
  PANEL_PORT="${PANEL_PORT:-3000}"
fi

# ---------------------------------------------------------------------------
# systemd service
# ---------------------------------------------------------------------------
c_green "==> Creating systemd service"
cat > "/etc/systemd/system/${SERVICE_NAME}.service" <<EOF
[Unit]
Description=ShadowPanel server management panel
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${INSTALL_DIR}/.env
ExecStart=/usr/bin/node ${INSTALL_DIR}/backend/app.js
Restart=on-failure
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now "${SERVICE_NAME}"

# ---------------------------------------------------------------------------
# Firewall (best-effort, skipped if ufw isn't active)
# ---------------------------------------------------------------------------
if command -v ufw >/dev/null 2>&1; then
  ufw allow "${PANEL_PORT}/tcp" >/dev/null 2>&1 || true
fi

SERVER_IP="$(curl -fsSL ifconfig.me 2>/dev/null || echo YOUR_SERVER_IP)"

c_green "=================================================================="
c_green " ShadowPanel is installed and running."
c_green " URL:      http://${SERVER_IP}:${PANEL_PORT}"
c_green " Service:  systemctl status ${SERVICE_NAME}"
c_green " Logs:     journalctl -u ${SERVICE_NAME} -f"
c_green " Config:   ${INSTALL_DIR}/.env"
c_green "=================================================================="
c_yellow "Remember to open port ${PANEL_PORT} in any external firewall / cloud"
c_yellow "security group if ufw isn't managing it, and put this behind a"
c_yellow "reverse proxy with HTTPS (e.g. Caddy or nginx + certbot) for real use."
