# frontend/src

The current UI is plain HTML/CSS/JS served directly from `frontend/public`
— there's no build step today, so this folder is empty.

It's reserved for if/when the UI moves to a framework with a build step
(React, Vue, etc.). In that case: source lives here, the build output gets
written to `frontend/public`, and `backend/app.js` keeps serving
`frontend/public` exactly as it does now — no backend changes required.
