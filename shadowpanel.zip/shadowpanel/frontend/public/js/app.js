const api = async (url, opts = {}) => {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

const el = (id) => document.getElementById(id);
const show = (screenId) => {
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  el(screenId).classList.add('active');
};

let currentUser = null;
let catalog = [];

async function boot() {
  try {
    currentUser = await api('/api/auth/me');
    el('userEmail').textContent = currentUser.email;
    show('dashScreen');
    await loadCatalog();
    await loadServers();
  } catch {
    show('loginScreen');
  }
}

// ---------- Login ----------
el('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  el('loginError').textContent = '';
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: el('loginEmail').value,
        password: el('loginPassword').value,
      }),
    });
    currentUser = data;
    el('userEmail').textContent = data.email;
    show('dashScreen');
    await loadCatalog();
    await loadServers();
  } catch (err) {
    el('loginError').textContent = err.message;
  }
});

el('logoutBtn').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  show('loginScreen');
});

// ---------- Catalog ----------
async function loadCatalog() {
  catalog = await api('/api/servers/catalog');
  const sel = el('nsCatalog');
  sel.innerHTML = catalog.map((c) => `<option value="${c.key}">${c.label}</option>`).join('');
}

// ---------- Server list ----------
async function loadServers() {
  const servers = await api('/api/servers');
  const grid = el('serverGrid');
  el('emptyState').hidden = servers.length > 0;
  grid.innerHTML = servers
    .map((s) => {
      const running = s.running;
      return `
      <div class="server-card" data-id="${s.id}">
        <div class="server-card-head">
          <span class="server-name">${escapeHtml(s.name)}</span>
          <span class="status-pill ${running ? 'running' : 'stopped'}">
            <span class="status-dot"></span>${running ? 'Online' : 'Offline'}
          </span>
        </div>
        <div class="server-meta">
          Image: <span>${escapeHtml(s.image)}</span><br/>
          Port: <span>${escapeHtml(s.port_map || '-')}</span> &middot;
          RAM: <span>${s.memory_mb} MB</span> &middot;
          CPU: <span>${s.cpu_cores}</span>
        </div>
        <div class="server-actions">
          <button class="btn" data-act="start">Start</button>
          <button class="btn" data-act="stop">Stop</button>
          <button class="btn" data-act="restart">Restart</button>
          <button class="btn" data-act="logs">Console</button>
          <button class="btn btn-danger" data-act="remove">Delete</button>
        </div>
      </div>`;
    })
    .join('');
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

el('serverGrid').addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-act]');
  if (!btn) return;
  const card = e.target.closest('.server-card');
  const id = card.dataset.id;
  const act = btn.dataset.act;

  if (act === 'logs') return openConsole(id, card.querySelector('.server-name').textContent);
  if (act === 'remove' && !confirm('Delete this server permanently? This cannot be undone.')) return;

  btn.disabled = true;
  try {
    await api(`/api/servers/${id}/power/${act}`, { method: 'POST' });
    await loadServers();
  } catch (err) {
    alert(err.message);
  } finally {
    btn.disabled = false;
  }
});

// ---------- New server modal ----------
el('newServerBtn').addEventListener('click', () => { el('newServerModal').hidden = false; });
el('nsCancel').addEventListener('click', () => { el('newServerModal').hidden = true; });

el('newServerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  el('nsError').textContent = '';
  el('nsSubmit').disabled = true;
  try {
    await api('/api/servers', {
      method: 'POST',
      body: JSON.stringify({
        name: el('nsName').value.trim(),
        catalogKey: el('nsCatalog').value,
        hostPort: el('nsPort').value,
        memoryMb: el('nsMemory').value,
        cpuCores: el('nsCpu').value,
      }),
    });
    el('newServerModal').hidden = true;
    el('newServerForm').reset();
    await loadServers();
  } catch (err) {
    el('nsError').textContent = err.message;
  } finally {
    el('nsSubmit').disabled = false;
  }
});

// ---------- Console modal ----------
let consoleServerId = null;

async function openConsole(id, name) {
  consoleServerId = id;
  el('consoleTitle').textContent = `Console — ${name}`;
  el('consoleModal').hidden = false;
  await refreshConsole();
}

async function refreshConsole() {
  el('consoleOutput').textContent = 'Loading logs…';
  try {
    const data = await api(`/api/servers/${consoleServerId}/logs`);
    el('consoleOutput').textContent = data.logs || '(no output yet)';
    el('consoleOutput').scrollTop = el('consoleOutput').scrollHeight;
  } catch (err) {
    el('consoleOutput').textContent = `Error: ${err.message}`;
  }
}

el('consoleRefresh').addEventListener('click', refreshConsole);
el('consoleClose').addEventListener('click', () => { el('consoleModal').hidden = true; });

boot();
